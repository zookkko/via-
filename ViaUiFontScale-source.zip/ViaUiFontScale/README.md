# Via UI Font Scale (LSPosed)

一个经典 Xposed API 模块原型，目标是调整 **Via 浏览器原生应用界面** 中通过 `TextView.setTextSize()` 设置的字号；不修改网页 CSS、WebView 页面缩放或网页默认字体。

## 当前状态

- 目标环境：Android 16 / HyperOS 3；用户报告的 Via 7.3.3、LSPosed 2.2.1 (7912) 尚未实机验证。
- 调节范围：50%–200%，默认 100%。
- Xposed API：经典 API 82，入口位于 `assets/xposed_init`。
- **这是未实机验证的源码原型，不要当作已测试的正式 APK。** 有些原生控件字号来自布局 XML、Compose 或自绘，可能不会被此 hook 覆盖；如果 Via 的实际包名不是 `mark.via.gp` 或 `mark.via`，需将真实包名加入 `ViaFontHook.java`。
- 本版本改为通过一个只返回字号倍率整数的导出 ContentProvider 供 Via 进程读取，避免依赖跨应用读取私有 SharedPreferences。该 Provider 不提供写入接口，但仍然是无权限导出组件，发布前可进一步加固。倍率在 Via 启动时读取，调整后需要强行停止并重启 Via。

## 构建

需要 JDK 17、Android SDK Platform 35、Android Build Tools，以及可联网下载 Gradle 插件依赖的环境：

```bash
gradle assembleDebug
```

输出通常位于 `app/build/outputs/apk/debug/app-debug.apk`。本项目未附带 Gradle Wrapper。请在联网的 Android Studio 环境中打开项目并同步 Gradle，或先生成 Gradle Wrapper，再执行构建。当前交付环境没有安装 Gradle/Android SDK，且无法解析外网域名，因此无法在此环境完成真实 APK 编译。

## 安装和测试

1. 安装 APK。
2. 在 LSPosed 管理器中启用模块，并在作用域中只勾选 Via 浏览器。
3. 打开模块应用，将倍率设为所需数值。
4. 强行停止 Via 后重新打开；测试地址栏、菜单、设置页、书签等原生界面。
5. 检查网页字号是否保持不变，并在 LSPosed 日志中检查 `ViaUiFontScale`。

## GitHub 发布

创建一个空 GitHub repository，然后在项目目录执行：

```bash
git init
git add .
git commit -m "Initial Via UI font scale module"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/ViaUiFontScale.git
git push -u origin main
```

建议先通过 Android Studio 成功构建并在目标设备测试，再通过 GitHub Actions 或本地构建发布 APK。不要把未经测试的 APK 标注为稳定版。
