package dev.example.viafontscale;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREF = "settings";
    private static final String KEY = "scale_percent";
    private TextView value;
    private int percent;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        percent = getSharedPreferences(PREF, MODE_PRIVATE).getInt(KEY, 100);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Via 浏览器本体字体大小");
        title.setTextSize(22);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("仅尝试调整应用原生 TextView 字体，不影响网页内容字号。修改后请强行停止并重新打开 Via。\n\n需在 LSPosed 中启用模块，并勾选 Via 浏览器作用域。");
        note.setTextSize(14);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = 12;
        root.addView(note, np);

        value = new TextView(this);
        value.setTextSize(18);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = 24;
        root.addView(value, vp);

        SeekBar seek = new SeekBar(this);
        seek.setMax(100); // 50% .. 200%
        percent = Math.max(50, Math.min(200, percent));
        seek.setProgress(percent - 50);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 12;
        root.addView(seek, sp);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean user) {
                percent = p + 50;
                value.setText("字体倍率：" + percent + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) { saveScale(); }
        });
        value.setText("字体倍率：" + percent + "%");

        Button reset = new Button(this);
        reset.setText("恢复 100%");
        reset.setOnClickListener(v -> {
            percent = 100; seek.setProgress(50);
            saveScale();
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 16;
        root.addView(reset, bp);
        setContentView(root);
    }

    private void saveScale() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt(KEY, percent).apply();
    }
}
