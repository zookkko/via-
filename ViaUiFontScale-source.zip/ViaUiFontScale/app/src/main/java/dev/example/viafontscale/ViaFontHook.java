package dev.example.viafontscale;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.TextView;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ViaFontHook implements IXposedHookLoadPackage {
    private static final String MODULE_PACKAGE = "dev.example.viafontscale";
    private static final Uri SETTINGS_URI = Uri.parse("content://" + MODULE_PACKAGE + ".settings");
    private static final String[] TARGETS = {"mark.via.gp", "mark.via"};
    private static volatile int cachedPercent = 100;

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        boolean target = false;
        for (String name : TARGETS) {
            if (name.equals(lpparam.packageName)) { target = true; break; }
        }
        if (!target) return;

        try {
            XposedHelpers.findAndHookMethod("android.app.Application", lpparam.classLoader,
                "attach", Context.class, new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            Context context = (Context) param.args[0];
                            Bundle result = context.getContentResolver().call(SETTINGS_URI, "getScale", null, null);
                            if (result != null) {
                                cachedPercent = Math.max(50, Math.min(200, result.getInt("scale_percent", 100)));
                            }
                            XposedBridge.log("ViaUiFontScale: scale=" + cachedPercent + "%");
                        } catch (Throwable t) {
                            XposedBridge.log("ViaUiFontScale: could not read settings; using " + cachedPercent + "%: " + t);
                        }
                    }
                });

            // TextView.setTextSize(float) always takes SP.
            XposedHelpers.findAndHookMethod(TextView.class, "setTextSize", float.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    param.args[0] = ((Float) param.args[0]) * scaleFactor();
                }
            });
            // The two-argument overload accepts an explicit unit. Only scale SP, not PX/DP.
            XposedHelpers.findAndHookMethod(TextView.class, "setTextSize", int.class, float.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    int unit = (Integer) param.args[0];
                    if (unit == TypedValue.COMPLEX_UNIT_SP) {
                        param.args[1] = ((Float) param.args[1]) * scaleFactor();
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("ViaUiFontScale hook error: " + t);
        }
    }

    private static float scaleFactor() {
        return Math.max(50, Math.min(200, cachedPercent)) / 100.0f;
    }
}
