package dev.example.viafontscale;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/** Exposes only the font-scale integer to the hooked browser process. */
public class SettingsProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (!"getScale".equals(method) || getContext() == null) return Bundle.EMPTY;
        int value = getContext().getSharedPreferences("settings", 0).getInt("scale_percent", 100);
        value = Math.max(50, Math.min(200, value));
        Bundle result = new Bundle();
        result.putInt("scale_percent", value);
        return result;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
